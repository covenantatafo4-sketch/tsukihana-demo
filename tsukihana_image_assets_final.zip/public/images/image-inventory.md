# Tsukihana 月花 — Image Inventory

Prepared only from authentic photographs visible in the supplied Instagram screenshots.
No people, faces, bodies, clothing, objects, or backgrounds were AI-generated or reconstructed.

## owner/owner-hero.jpg
Source: `1000059729.jpg`
Content: Authentic photograph of the salon owner with another woman in the salon.
Recommended section: Homepage hero.
Original photo crop: 657 × 511 px.
Output: 1312 × 738 px.
Cropping: 16:9 landscape crop, preserving both people.
Corrections: Very mild contrast/sharpening.

## owner/owner-hero-mobile.jpg
Source: `1000059729.jpg`
Content: Same authentic photograph.
Recommended section: Mobile homepage hero.
Output: 828 × 1035 px.
Cropping: 4:5 portrait crop, centered to retain both people.
Corrections: Very mild contrast/sharpening.

## owner/owner-about.jpg
Source: `1000059728.jpg`
Content: Authentic portrait photograph of the salon owner seated in the salon.
Recommended section: About / owner.
Original photo crop: approximately 500 × 395 px.
Output: 500 × 395 px.
Cropping: Exact photographic area isolated from the surrounding Instagram graphic.
Corrections: Very mild contrast/sharpening.

## owner/owner-profile-circle.jpg
Source: `1000059747.jpg`
Content: Authentic circular profile photograph of the salon owner.
Recommended section: Small owner/profile UI only.
Output: 800 × 800 px.
Cropping: Circular source image retained; no pixels outside the original circle were invented.
Corrections: Very mild contrast/sharpening.

## gallery/gallery-01.jpg
Source: `1000059731.jpg`
Content: Authentic photograph of the salon owner with another woman.
Recommended section: Gallery.
Original photo crop: 548 × 518 px.
Output: 1200 × 1134 px.
Cropping: Aspect-preserving photographic crop.
Corrections: Very mild contrast/sharpening.

## gallery/gallery-02.jpg
Source: `1000059729.jpg`
Content: Authentic photograph of the salon owner with another woman.
Recommended section: Gallery / customer experience.
Original photo crop: 657 × 511 px.
Output: 1200 × 933 px.
Cropping: Aspect-preserving photographic crop.
Corrections: Very mild contrast/sharpening.

## customers/customer-01.jpg
Source: `1000059729.jpg`
Content: Authentic photograph showing the salon owner with another woman.
Recommended section: Customer experience, only if the site's content team confirms the person's role.
Output: 1200 × 933 px.
Cropping: Aspect-preserving.
Corrections: Very mild contrast/sharpening.

## gallery/gallery-03.jpg
Source: `1000059747.jpg`
Content: Authentic circular profile photograph of the salon owner.
Recommended section: Gallery only if a circular portrait is acceptable; otherwise use as profile image.
Output: 800 × 800 px.
Cropping: Original circular composition retained.
Corrections: Very mild contrast/sharpening.

## Excluded sources
`1000059730.jpg` and `1000059732.jpg`: infographic/text slides with no usable real photograph.
`1000059727.jpg`: contains a real owner photograph, but a large privacy graphic covers the other person's face and substantial graphic text overlays the composition. It was not aggressively cleaned or reconstructed.
`1000059735.jpg`: Instagram profile page; its thumbnails are too small and embedded in UI to be treated as clean source photographs.

## Important
No salon interior, foot-care, yomogi-steam, or other service photographs were fabricated. Those assets should only be added after screenshots containing those real photographs are supplied.
